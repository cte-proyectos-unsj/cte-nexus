from fastapi import FastAPI

app = FastAPI(title="CTE Backend")

@app.get("/")
def root():
    return {"status": "Backend activo"}

from fastapi import FastAPI
from app.database import engine, Base

# importar modelos
from app.models import user

app = FastAPI()

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

@app.get("/")
def root():
    return {"msg": "DB conectada"}

from fastapi import FastAPI
from app.database import engine, Base
from app.models import user
from app.routers import auth

app = FastAPI()

Base.metadata.create_all(bind=engine)

app.include_router(auth.router)

from app.routers import test_admin
app.include_router(test_admin.router)

from app.models import turno

from app.routers import turnos

app.include_router(turnos.router)

from app.models import reparacion

from app.routers import reparaciones

app.include_router(reparaciones.router)

from app.models import curso
from app.models import leccion

from app.routers import cursos
from app.routers import lecciones

app.include_router(cursos.router)
app.include_router(lecciones.router)

from app.models import cuestionario

from app.routers import quiz
app.include_router(quiz.router)

from app.models import progreso

from app.routers import progreso
app.include_router(progreso.router)

from app.models import practica
from app.models import envio

from app.routers import practicas
app.include_router(practicas.router)

from app.models import ranking

from app.routers import ranking
app.include_router(ranking.router)