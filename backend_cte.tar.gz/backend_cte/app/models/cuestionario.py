from sqlalchemy import Column, Integer, String, ForeignKey
from app.database import Base


class Cuestionario(Base):
    __tablename__ = "cuestionarios"

    id = Column(Integer, primary_key=True, index=True)

    curso_id = Column(Integer, ForeignKey("cursos.id"))

    pregunta = Column(String)

    opcion_a = Column(String)
    opcion_b = Column(String)
    opcion_c = Column(String)
    opcion_d = Column(String)

    correcta = Column(String)  # A/B/C/D
