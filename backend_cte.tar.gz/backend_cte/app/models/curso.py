from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from app.database import Base


class Curso(Base):
    __tablename__ = "cursos"

    id = Column(Integer, primary_key=True, index=True)

    titulo = Column(String)
    descripcion = Column(String)

    profesor_id = Column(Integer, ForeignKey("users.id"))

    portada_url = Column(String)

    profesor = relationship("User")
