from sqlalchemy import Column, Integer, Text, DateTime, ForeignKey
from datetime import datetime
from app.database import Base


class Envio(Base):
    __tablename__ = "envios"

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(Integer, ForeignKey("users.id"))
    practica_id = Column(Integer, ForeignKey("practicas.id"))

    codigo = Column(Text)

    resultado = Column(Text)
    salida_obtenida = Column(Text)

    puntaje = Column(Integer)

    fecha = Column(DateTime, default=datetime.utcnow)
