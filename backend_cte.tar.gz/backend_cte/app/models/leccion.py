from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from app.database import Base


class Leccion(Base):
    __tablename__ = "lecciones"

    id = Column(Integer, primary_key=True, index=True)

    curso_id = Column(Integer, ForeignKey("cursos.id"))

    titulo = Column(String)
    contenido_html = Column(String)

    video_url = Column(String)
    material_pdf = Column(String)

    curso = relationship("Curso")
