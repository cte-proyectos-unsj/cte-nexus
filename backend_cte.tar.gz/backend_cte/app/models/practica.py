from sqlalchemy import Column, Integer, String, Text
from app.database import Base


class Practica(Base):
    __tablename__ = "practicas"

    id = Column(Integer, primary_key=True, index=True)

    titulo = Column(String)
    descripcion = Column(Text)

    lenguaje = Column(String)

    tests_entrada = Column(Text)   # JSON en texto
    tests_salida = Column(Text)
