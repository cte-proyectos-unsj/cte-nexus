from sqlalchemy import Column, Integer, Boolean, DateTime, ForeignKey
from datetime import datetime
from app.database import Base


class Progreso(Base):
    __tablename__ = "progreso_curso"

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(Integer, ForeignKey("users.id"))
    curso_id = Column(Integer, ForeignKey("cursos.id"))
    leccion_id = Column(Integer, ForeignKey("lecciones.id"))

    completado = Column(Boolean, default=False)
    fecha = Column(DateTime, default=datetime.utcnow)
