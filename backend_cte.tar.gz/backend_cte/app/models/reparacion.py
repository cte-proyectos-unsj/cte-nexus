from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime

from app.database import Base


class Reparacion(Base):
    __tablename__ = "reparaciones"

    id = Column(Integer, primary_key=True, index=True)

    turno_id = Column(Integer, ForeignKey("turnos.id"))
    tecnico_id = Column(Integer, ForeignKey("users.id"))

    diagnostico = Column(String)
    acciones = Column(String)

    costo_estimado = Column(Float)
    costo_final = Column(Float)

    estado = Column(
        String,
        default="diagnostico"
    )

    fecha_inicio = Column(DateTime, default=datetime.utcnow)
    fecha_fin = Column(DateTime)

    turno = relationship("Turno")
    tecnico = relationship("User")

