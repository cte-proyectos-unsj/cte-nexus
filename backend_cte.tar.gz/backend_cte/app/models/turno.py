from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base
from datetime import datetime


class Turno(Base):
    __tablename__ = "turnos"

    id = Column(Integer, primary_key=True, index=True)

    tipo = Column(String)
    descripcion = Column(String)

    fecha_solicitud = Column(DateTime, default=datetime.utcnow)
    fecha_turno = Column(DateTime)

    estado = Column(
        String,
        default="pendiente"
    )

    user_id = Column(Integer, ForeignKey("users.id"))

    usuario = relationship("User")

