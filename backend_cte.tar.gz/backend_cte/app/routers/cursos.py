from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.curso import Curso
from app.utils.deps import get_current_user, require_role

router = APIRouter(prefix="/cursos", tags=["Cursos"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Crear curso (staff)
@router.post("/")
def crear(
    titulo: str,
    descripcion: str,
    portada_url: str = None,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    curso = Curso(
        titulo=titulo,
        descripcion=descripcion,
        profesor_id=user.id,
        portada_url=portada_url
    )

    db.add(curso)
    db.commit()
    db.refresh(curso)

    return curso


# Listar cursos
@router.get("/")
def listar(db: Session = Depends(get_db)):
    return db.query(Curso).all()


# Ver uno
@router.get("/{id}")
def ver(id: int, db: Session = Depends(get_db)):
    return db.query(Curso).get(id)


# Eliminar
@router.delete("/{id}")
def eliminar(
    id: int,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    curso = db.query(Curso).get(id)
    db.delete(curso)
    db.commit()
    return {"msg": "Curso eliminado"}
