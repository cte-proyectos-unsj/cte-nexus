from app.models.ranking import Ranking

# actualizar ranking
rank = db.query(Ranking).filter(
    Ranking.user_id == user.id
).first()

if not rank:
    rank = Ranking(
        user_id=user.id,
        puntaje_total=puntaje
    )
    db.add(rank)
else:
    rank.puntaje_total += puntaje

db.commit()