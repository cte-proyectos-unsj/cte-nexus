from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.leccion import Leccion
from app.utils.deps import require_role

router = APIRouter(prefix="/lecciones", tags=["Lecciones"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Crear lección
@router.post("/")
def crear(
    curso_id: int,
    titulo: str,
    contenido_html: str = None,
    video_url: str = None,
    material_pdf: str = None,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    lec = Leccion(
        curso_id=curso_id,
        titulo=titulo,
        contenido_html=contenido_html,
        video_url=video_url,
        material_pdf=material_pdf
    )

    db.add(lec)
    db.commit()
    db.refresh(lec)

    return lec


# Listar por curso
@router.get("/curso/{curso_id}")
def listar(curso_id: int, db: Session = Depends(get_db)):
    return db.query(Leccion).filter(
        Leccion.curso_id == curso_id
    ).all()
