from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.practica import Practica
from app.utils.deps import require_role

router = APIRouter(prefix="/practicas", tags=["Practicas"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Crear práctica
@router.post("/")
def crear(
    titulo: str,
    descripcion: str,
    lenguaje: str,
    tests_entrada: str,
    tests_salida: str,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    p = Practica(
        titulo=titulo,
        descripcion=descripcion,
        lenguaje=lenguaje,
        tests_entrada=tests_entrada,
        tests_salida=tests_salida
    )

    db.add(p)
    db.commit()
    db.refresh(p)

    return p


# Listar
@router.get("/")
def listar(db: Session = Depends(get_db)):
    return db.query(Practica).all()


# Ver una
@router.get("/{id}")
def ver(id: int, db: Session = Depends(get_db)):
    return db.query(Practica).get(id)
