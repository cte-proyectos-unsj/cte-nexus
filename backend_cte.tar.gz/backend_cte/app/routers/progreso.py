from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.progreso import Progreso
from app.utils.deps import get_current_user

router = APIRouter(prefix="/progreso", tags=["Progreso"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Marcar completado
@router.post("/")
def completar(
    curso_id: int,
    leccion_id: int,
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    prog = Progreso(
        user_id=user.id,
        curso_id=curso_id,
        leccion_id=leccion_id,
        completado=True
    )

    db.add(prog)
    db.commit()

    return {"msg": "Progreso guardado"}


# Ver progreso del curso
@router.get("/curso/{curso_id}")
def ver(
    curso_id: int,
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return db.query(Progreso).filter(
        Progreso.user_id == user.id,
        Progreso.curso_id == curso_id
    ).all()

from fastapi.responses import FileResponse
from app.services.certificados import generar_certificado
import os


@router.get("/certificado/{curso_id}")
def certificado(
    curso_id: int,
    user=Depends(get_current_user)
):
    archivo = f"cert_{user.id}_{curso_id}.pdf"

    generar_certificado(
        user.nombre,
        f"Curso {curso_id}",
        archivo
    )

    return FileResponse(
        archivo,
        media_type="application/pdf",
        filename="certificado.pdf"
    )
