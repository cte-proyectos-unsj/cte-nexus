from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.cuestionario import Cuestionario
from app.utils.deps import require_role

router = APIRouter(prefix="/quiz", tags=["Quiz"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Crear pregunta (staff)
@router.post("/")
def crear(
    curso_id: int,
    pregunta: str,
    opcion_a: str,
    opcion_b: str,
    opcion_c: str,
    opcion_d: str,
    correcta: str,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    q = Cuestionario(
        curso_id=curso_id,
        pregunta=pregunta,
        opcion_a=opcion_a,
        opcion_b=opcion_b,
        opcion_c=opcion_c,
        opcion_d=opcion_d,
        correcta=correcta.upper()
    )

    db.add(q)
    db.commit()
    db.refresh(q)

    return q


# Ver preguntas de un curso
@router.get("/curso/{curso_id}")
def listar(curso_id: int, db: Session = Depends(get_db)):
    return db.query(Cuestionario).filter(
        Cuestionario.curso_id == curso_id
    ).all()


# Responder pregunta
@router.post("/{id}/responder")
def responder(
    id: int,
    respuesta: str,
    db: Session = Depends(get_db)
):
    q = db.query(Cuestionario).get(id)

    correcta = q.correcta.upper()
    usuario = respuesta.upper()

    return {
        "correcto": usuario == correcta,
        "respuesta_correcta": correcta
    }
