from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from datetime import datetime

from app.database import SessionLocal
from app.models.reparacion import Reparacion
from app.utils.deps import get_current_user, require_role

router = APIRouter(prefix="/reparaciones", tags=["Reparaciones"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Crear reparación (solo staff)
@router.post("/")
def crear(
    turno_id: int,
    tecnico_id: int,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    rep = Reparacion(
        turno_id=turno_id,
        tecnico_id=tecnico_id
    )
    db.add(rep)
    db.commit()
    db.refresh(rep)
    return rep


# Listar todas
@router.get("/")
def listar(
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    return db.query(Reparacion).all()


# Ver una
@router.get("/{id}")
def ver(
    id: int,
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return db.query(Reparacion).get(id)


# Actualizar estado
@router.patch("/{id}/estado")
def estado(
    id: int,
    estado: str,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    rep = db.query(Reparacion).get(id)
    rep.estado = estado

    if estado == "terminado":
        rep.fecha_fin = datetime.utcnow()

    db.commit()
    return rep


# Actualizar costos
@router.patch("/{id}/costo")
def costo(
    id: int,
    estimado: float = None,
    final: float = None,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    rep = db.query(Reparacion).get(id)

    if estimado is not None:
        rep.costo_estimado = estimado

    if final is not None:
        rep.costo_final = final

    db.commit()
    return rep

if estado == "terminado":
    from app.models.user import User
    cliente = db.query(User).get(rep.turno.user_id)

    enviar_email(
        cliente.email,
        "Reparación terminada",
        "Tu equipo está listo para retirar."
    )