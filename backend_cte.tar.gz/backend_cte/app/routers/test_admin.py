from fastapi import APIRouter, Depends
from app.utils.deps import require_role

router = APIRouter(prefix="/admin", tags=["Admin"])

@router.get("/panel")
def admin_panel(user = Depends(require_role("admin"))):
    return {"msg": "Bienvenido admin"}
