from reportlab.pdfgen import canvas
from datetime import datetime


def generar_certificado(nombre, curso, archivo):
    c = canvas.Canvas(archivo)

    c.setFont("Helvetica", 20)
    c.drawString(100, 700, "CERTIFICADO")

    c.setFont("Helvetica", 14)
    c.drawString(100, 650, f"Se certifica que:")
    c.drawString(100, 620, nombre)

    c.drawString(100, 580, "Completó el curso:")
    c.drawString(100, 550, curso)

    c.drawString(100, 500, str(datetime.now().date()))

    c.save()
