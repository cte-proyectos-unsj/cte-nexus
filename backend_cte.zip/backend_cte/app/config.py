import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    """
    Configuración central del proyecto cargada desde variables de entorno.
    """

    PROJECT_NAME: str = os.getenv("PROJECT_NAME", "CTE Backend")

    # Base de datos principal
    DB_USER: str | None = os.getenv("DB_USER")
    DB_PASS: str | None = os.getenv("DB_PASS")
    DB_HOST: str = os.getenv("DB_HOST", "localhost")
    DB_PORT: str = os.getenv("DB_PORT", "5432")
    DB_NAME: str = os.getenv("DB_NAME", "cte_db")

    # JWT / Seguridad
    SECRET_KEY: str = os.getenv("SECRET_KEY", "change_this_secret_in_prod")
    ALGORITHM: str = os.getenv("ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(
        os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60")
    )

    # SMTP / Email
    SMTP_SERVER: str | None = os.getenv("SMTP_SERVER")
    SMTP_PORT: int = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USER: str | None = os.getenv("SMTP_USER")
    SMTP_PASS: str | None = os.getenv("SMTP_PASS")

    # Base de datos de tests opcional
    TEST_DATABASE_URL: str | None = os.getenv(
        "TEST_DATABASE_URL",
        "postgresql://postgres:postgres@localhost/cte_db_test",
    )


settings = Settings()
