import os

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.config import settings


def _build_database_url() -> str:
    """
    Construye la URL de conexión a la base de datos.
    Usa una BD separada cuando TESTING=true.
    """
    if os.getenv("TESTING") == "true" and settings.TEST_DATABASE_URL:
        return settings.TEST_DATABASE_URL

    if settings.DB_USER and settings.DB_PASS:
        return (
            f"postgresql://{settings.DB_USER}:"
            f"{settings.DB_PASS}@"
            f"{settings.DB_HOST}:"
            f"{settings.DB_PORT}/"
            f"{settings.DB_NAME}"
        )

    # Fallback mínimo para desarrollo local sin variables definidas
    return os.getenv(
        "DATABASE_URL",
        "postgresql://cte_user:cte1234@localhost/cte_platform",
    )


DATABASE_URL = _build_database_url()

engine = create_engine(DATABASE_URL)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)

Base = declarative_base()
