from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import Base, engine

# Importar modelos para que SQLAlchemy conozca todas las tablas
from app.models import (  # noqa: F401
    curso,
    cuestionario,
    envio,
    leccion,
    practica,
    progreso,
    ranking,
    reparacion,
    turno,
    user,
)
from app.routers import (  # noqa: F401
    auth,
    cursos,
    envios,
    lecciones,
    practicas,
    progreso as progreso_router,
    quiz,
    ranking as ranking_router,
    reparaciones,
    turnos,
)


app = FastAPI(title=settings.PROJECT_NAME)

# CORS básico para permitir al frontend acceder a la API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup() -> None:
    Base.metadata.create_all(bind=engine)


@app.get("/")
def root():
    return {"status": "Backend activo"}


# Routers principales según el plan del CTE
app.include_router(auth.router)
app.include_router(turnos.router)
app.include_router(reparaciones.router)
app.include_router(cursos.router)
app.include_router(lecciones.router)
app.include_router(quiz.router)
app.include_router(progreso_router.router)
app.include_router(practicas.router)
app.include_router(envios.router)
app.include_router(ranking_router.router)
