from sqlalchemy import Column, Integer, ForeignKey
from app.database import Base


class Ranking(Base):
    __tablename__ = "ranking"

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(Integer, ForeignKey("users.id"))
    puntaje_total = Column(Integer, default=0)