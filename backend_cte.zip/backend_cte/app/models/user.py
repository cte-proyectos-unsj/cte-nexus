from datetime import datetime

from sqlalchemy import Column, DateTime, Integer, String

from app.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)

    # rol: alumno / staff / admin
    rol = Column(String, default="alumno", nullable=False)

    fecha_registro = Column(DateTime, default=datetime.utcnow, nullable=False)
