from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.envio import Envio
from app.models.practica import Practica
from app.models.ranking import Ranking
from app.services.code_executor import ejecutar_codigo
from app.utils.deps import get_current_user, require_role


router = APIRouter(prefix="/envios", tags=["Envios"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _actualizar_ranking(db: Session, user_id: int, puntaje: int) -> None:
    rank = db.query(Ranking).filter(Ranking.user_id == user_id).first()

    if not rank:
        rank = Ranking(user_id=user_id, puntaje_total=puntaje)
        db.add(rank)
    else:
        rank.puntaje_total += puntaje


@router.post("/")
def enviar_codigo(
    practica_id: int,
    codigo: str,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    practica = db.query(Practica).filter(Practica.id == practica_id).first()
    if not practica:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Práctica no encontrada"
        )

    resultado = ejecutar_codigo(
        practica.lenguaje,
        codigo,
        practica.tests_entrada,
        practica.tests_salida,
    )

    envio = Envio(
        user_id=user.id,
        practica_id=practica.id,
        codigo=codigo,
        resultado=resultado.get("resultado"),
        salida_obtenida=resultado.get("salida_obtenida"),
        puntaje=resultado.get("puntaje", 0),
    )

    db.add(envio)
    _actualizar_ranking(db, user.id, envio.puntaje or 0)
    db.commit()
    db.refresh(envio)

    return {
        "envio": envio,
        "resultado": resultado,
    }


@router.get("/user/{user_id}")
def historial_usuario(
    user_id: int,
    current=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if current.id != user_id and current.rol not in ("staff", "admin"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No autorizado")
    return (
        db.query(Envio)
        .filter(Envio.user_id == user_id)
        .order_by(Envio.fecha.desc())
        .all()
    )


@router.get("/practica/{practica_id}")
def envios_por_practica(
    practica_id: int,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db),
):
    return (
        db.query(Envio)
        .filter(Envio.practica_id == practica_id)
        .order_by(Envio.fecha.desc())
        .all()
    )
