from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.ranking import Ranking
from app.utils.deps import get_current_user

router = APIRouter(prefix="/ranking", tags=["Ranking"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Ranking general
@router.get("/")
def general(db: Session = Depends(get_db)):
    return db.query(Ranking).order_by(
        Ranking.puntaje_total.desc()
    ).all()


# Puntaje individual
@router.get("/me")
def mi_puntaje(
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return db.query(Ranking).filter(
        Ranking.user_id == user.id
    ).first()