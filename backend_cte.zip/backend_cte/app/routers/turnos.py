from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from datetime import datetime

from app.database import SessionLocal
from app.models.turno import Turno
from app.utils.deps import get_current_user, require_role

router = APIRouter(prefix="/turnos", tags=["Turnos"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Crear turno
@router.post("/")
def crear_turno(
    tipo: str,
    descripcion: str,
    fecha_turno: datetime,
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    turno = Turno(
        tipo=tipo,
        descripcion=descripcion,
        fecha_turno=fecha_turno,
        user_id=user.id
    )

    db.add(turno)
    db.commit()
    db.refresh(turno)

    # Notificar por email al crear turno (si hay SMTP configurado)
    try:
        from app.services.email_service import enviar_email

        enviar_email(
            user.email,
            "Turno creado",
            f"Tu turno fue creado para {fecha_turno}",
        )
    except Exception:
        # No romper la API si el email falla
        pass

    return turno


# Mis turnos
@router.get("/mios")
def mis_turnos(
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return db.query(Turno).filter(Turno.user_id == user.id).all()


# Listar todos (staff/admin)
@router.get("/")
def listar(
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    return db.query(Turno).all()


# Ver un turno por id
@router.get("/{id}")
def ver_turno(
    id: int,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    turno = db.query(Turno).filter(Turno.id == id).first()
    if not turno:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Turno no encontrado")
    if turno.user_id != user.id and user.rol not in ("staff", "admin"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No autorizado")
    return turno


# Editar turno (solo dueño antes de que sea atendido)
@router.put("/{id}")
def editar_turno(
    id: int,
    tipo: str,
    descripcion: str,
    fecha_turno: datetime,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    turno = db.query(Turno).filter(Turno.id == id).first()
    if not turno:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Turno no encontrado")
    if turno.user_id != user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No autorizado")

    turno.tipo = tipo
    turno.descripcion = descripcion
    turno.fecha_turno = fecha_turno
    db.commit()
    db.refresh(turno)
    return turno


# Cambiar estado
@router.patch("/{id}/estado")
def cambiar_estado(
    id: int,
    estado: str,
    user=Depends(require_role("staff")),
    db: Session = Depends(get_db)
):
    turno = db.query(Turno).filter(Turno.id == id).first()
    if not turno:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Turno no encontrado")
    turno.estado = estado
    db.commit()
    return turno


# Eliminar
@router.delete("/{id}")
def eliminar_turno(
    id: int,
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    turno = db.query(Turno).filter(Turno.id == id).first()
    if not turno:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Turno no encontrado")
    if turno.user_id != user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No autorizado")

    db.delete(turno)
    db.commit()

    return {"msg": "Eliminado"}