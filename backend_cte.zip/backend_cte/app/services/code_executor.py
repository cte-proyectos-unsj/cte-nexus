import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict


def ejecutar_codigo(
    lenguaje: str,
    codigo: str,
    tests_entrada: str,
    tests_salida: str,
    timeout: int = 3,
) -> Dict[str, Any]:
    """
    Ejecuta código enviado por el usuario de forma muy básica.
    Solo se soporta Python por ahora.

    tests_entrada / tests_salida vienen como JSON de listas de strings.
    """
    if lenguaje.lower() != "python":
        return {
            "resultado": "no_soportado",
            "salida_obtenida": "",
            "puntaje": 0,
            "detalle": "Solo se soporta Python en esta versión",
        }

    try:
        entradas = json.loads(tests_entrada or "[]")
        salidas_esperadas = json.loads(tests_salida or "[]")
    except json.JSONDecodeError:
        return {
            "resultado": "error_tests",
            "salida_obtenida": "",
            "puntaje": 0,
            "detalle": "tests_entrada/tests_salida no son JSON válidos",
        }

    passed = 0
    total = min(len(entradas), len(salidas_esperadas))
    all_outputs: list[str] = []

    with tempfile.TemporaryDirectory() as tmpdir:
        script_path = Path(tmpdir) / "solution.py"
        script_path.write_text(codigo, encoding="utf-8")

        for i in range(total):
            proc = subprocess.run(
                ["python", str(script_path)],
                input=str(entradas[i]),
                text=True,
                capture_output=True,
                timeout=timeout,
            )

            output = proc.stdout.strip()
            all_outputs.append(output)

            if output == str(salidas_esperadas[i]).strip():
                passed += 1

    puntaje = int((passed / total) * 100) if total > 0 else 0
    resultado = "aprobado" if puntaje == 100 else "parcial" if puntaje > 0 else "fallo"

    return {
        "resultado": resultado,
        "salida_obtenida": "\n".join(all_outputs),
        "puntaje": puntaje,
    }

