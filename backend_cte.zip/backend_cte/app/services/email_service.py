import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from app.config import settings


def enviar_email(destinatario: str, asunto: str, mensaje: str):

    msg = MIMEMultipart()
    msg["From"] = settings.SMTP_USER
    msg["To"] = destinatario
    msg["Subject"] = asunto

    msg.attach(MIMEText(mensaje, "plain"))

    try:
        servidor = smtplib.SMTP(settings.SMTP_SERVER, int(settings.SMTP_PORT))
        servidor.starttls()
        servidor.login(settings.SMTP_USER, settings.SMTP_PASS)
        servidor.send_message(msg)
        servidor.quit()
    except Exception as e:
        print("Error enviando email:", e)