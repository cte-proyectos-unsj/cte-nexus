def test_register(client):
    response = client.post(
        "/auth/register",
        params={
            "nombre": "Test",
            "email": "test@test.com",
            "password": "1234"
        }
    )
    assert response.status_code == 200